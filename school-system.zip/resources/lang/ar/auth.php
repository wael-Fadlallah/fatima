<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'login' => 'تسجيل الدخول بنجاح',
    'signup' => 'سجل بنجاح',
    'failed' => 'بيانات الاعتماد هذه غير متطابقة مع البيانات المسجلة لدينا.',
    'throttle' => 'عدد كبير جدا من محاولات الدخول. يرجى المحاولة مرة أخرى بعد :seconds ثانية.',
    'register_new_account' => 'تسجيل حساب جديد',
    'dont_have_account' => 'ليس لديك حساب؟',
    'already_have_account' => 'لديك حساب بالفعل؟'
];
