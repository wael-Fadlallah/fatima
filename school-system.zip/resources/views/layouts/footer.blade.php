

<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<!-- BEGIN: Footer-->

<!-- END: Footer-->


<!-- BEGIN: Vendor JS-->
<script src="{{ asset('vadmin/app-assets/vendors/js/vendors.min.js')}}"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="{{ asset('vadmin/app-assets/vendors/js/charts/apexcharts.min.js')}}"></script>
<script src="{{ asset('vadmin/app-assets/vendors/js/extensions/tether.min.js')}}"></script>
<script src="{{ asset('vadmin/app-assets/vendors/js/extensions/shepherd.min.js')}}"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="{{ asset('vadmin/app-assets/js/core/app-menu.js')}}"></script>
<script src="{{ asset('vadmin/app-assets/js/core/app.js')}}"></script>
<script src="{{ asset('vadmin/app-assets/js/scripts/components.js')}}"></script>
<!-- END: Theme JS-->
