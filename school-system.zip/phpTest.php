<php
echo phpinfo();
?>
