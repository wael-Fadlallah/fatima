<?php

namespace App\Http\Livewire\Classes\Students;

use Livewire\Component;

class ResultForm extends Component
{
    public function render()
    {
        return view('livewire.classes.students.result-form');
    }
}
