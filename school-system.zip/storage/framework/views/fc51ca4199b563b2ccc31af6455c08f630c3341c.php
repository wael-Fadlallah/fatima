<div>

    <p>

        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
            أضف معلمة
        </button>
    </p>


    <!-- Modal -->
    <div class="modal fade ModalCenter" id="exampleModalCenter" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">   أضف معلمة  </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teachers.teacher-form')->html();
} elseif ($_instance->childHasBeenRendered('ljKwce4')) {
    $componentId = $_instance->getRenderedChildComponentId('ljKwce4');
    $componentTag = $_instance->getRenderedChildComponentTagName('ljKwce4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ljKwce4');
} else {
    $response = \Livewire\Livewire::mount('teachers.teacher-form');
    $html = $response->html();
    $_instance->logRenderedChild('ljKwce4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>
            </div>
        </div>
    </div>

    <!-- image  Field -->
<div class="row">
    <div class="col-12">
        <?php if(session()->has('message')): ?>
            <div class="alert col-12 alert-success">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="col-12">

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>إسم المعلمة</th>
                <th>التوقيع</th>
            </tr>

            </thead>
            <tbody>
            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>#<?php echo e($teacher->id); ?></td>
                    <td><?php echo e($teacher->name); ?></td>
                    <td><?php echo getFirstMedia($teacher,'stamp'); ?></td>
                    <td><button class="btn btn-outline-dark" wire:click="upadteteacherModel(<?php echo e($teacher->id); ?>)" data-toggle="modal" data-target="#imageUpdate">تعديل </button>

                <button class="btn btn-outline-danger" wire:click="deleteModel(<?php echo e($teacher->id); ?>)" data-toggle="modal" data-target="#deleteData"><span class="fa fa-trash"></span></button>
            </td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr><td colspan="3"> <?php echo e($teachers->links()); ?> </td></tr>
            </tbody>
        </table>

    </div>
</div>


    <!-- Modal -->
    <div class="modal fade ModalCenterEdit" id="imageUpdate" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($upadteteacher->name??''); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teachers.teacher-image')->html();
} elseif ($_instance->childHasBeenRendered('51doOgW')) {
    $componentId = $_instance->getRenderedChildComponentId('51doOgW');
    $componentTag = $_instance->getRenderedChildComponentTagName('51doOgW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('51doOgW');
} else {
    $response = \Livewire\Livewire::mount('teachers.teacher-image');
    $html = $response->html();
    $_instance->logRenderedChild('51doOgW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



                </div>

            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade DeleteModalCenter" id="deleteData" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">هل تريد حذف  <?php echo e($upadteteacher->name??''); ?> ؟ </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">

                        <div class="btn btn-danger" wire:click="confirmDelete">
                            تأكيد
                        </div>



                </div>

            </div>
        </div>
    </div>
<?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/livewire/teachers/teacher.blade.php ENDPATH**/ ?>