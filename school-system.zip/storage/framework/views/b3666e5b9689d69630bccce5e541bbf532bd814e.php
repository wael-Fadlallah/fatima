


<div>
    <div class="row m-3">
        <div class="col-12">
            <?php if(session()->has('message')): ?>
                <div class="alert col-12 alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-12 mb-2"><h2 class="text-center">أدخل بيانات المعلمة   </h2></div>

        <div class="col-12 ">
            <div class="input-groupe">
                <lable>الإسم رباعي</lable>
                <input type="text" name="year2" class="form-control" wire:model="name" placeholder="">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="col-12"><span class="error text-danger"><?php echo e($message); ?></span></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-12 mt-1">
            <?php if($stamp): ?>
               إستعراض التوقيع :
                <img src="<?php echo e($stamp->temporaryUrl()); ?>" width="100%" height="200">
            <?php endif; ?>
            <div class="input-groupe">
                <lable>توقيع المعلمه</lable>
                <input type="file" name="stamp" class="form-control" wire:model="stamp" >
                <?php $__errorArgs = ['stamp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="col-12"><span class="error text-danger"><?php echo e($message); ?></span></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="col-12 m-1 text-center"><button wire:click="save" class=" btn btn-outline-info">
                حفظ
            </button>

        </div>
    </div>
</div>

<?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/livewire/teachers/teacher-form.blade.php ENDPATH**/ ?>