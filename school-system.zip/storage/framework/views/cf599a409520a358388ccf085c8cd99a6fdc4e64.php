<!DOCTYPE html>
<html lang="en">
<html class="loading" lang="en" data-textdirection="rtl">
<!-- BEGIN: Head-->

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="Vuexy admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
  <meta name="keywords" content="admin template, Vuexy admin template, dashboard template, flat admin template, responsive admin template, web app">
  <meta name="author" content="PIXINVENT">
  <title>مركز فاطمة بنت محمد صلى اللًه عليه وسلم  | <?php echo $__env->yieldContent('title'); ?></title>
  <link rel="apple-touch-icon" href="<?php echo e(asset('vadmin/app-assets/images/ico/apple-icon-120.png')); ?>">
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('vadmin/app-assets/images/ico/favicon.ico')); ?>">
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600" rel="stylesheet">

  <!-- BEGIN: Vendor CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vadmin/app-assets/vendors/css/vendors-rtl.min.css')); ?>">
  
  
  

  <!-- END: Vendor CSS-->

  <!-- BEGIN: Theme CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vadmin/app-assets/css-rtl/bootstrap.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vadmin/app-assets/css-rtl/bootstrap-extended.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vadmin/app-assets/css-rtl/colors.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vadmin/app-assets/css-rtl/components.css')); ?>">




  <!-- BEGIN: Custom CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vadmin/app-assets/css-rtl/custom-rtl.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('vadmin/assets/css/style-rtl.css')); ?>">

  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

  <!-- END: Custom CSS-->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400&display=swap" rel="stylesheet">
    <style>
        body{
            font-family: 'Tajawal', sans-serif;
        }
    </style>
  <?php echo $__env->yieldPushContent('style'); ?>
  <?php echo $__env->yieldPushContent('scripts'); ?>


    <!-- Livewire Styles -->
<style>
    [wire\:loading], [wire\:loading\.delay], [wire\:loading\.inline-block], [wire\:loading\.inline], [wire\:loading\.block], [wire\:loading\.flex], [wire\:loading\.table], [wire\:loading\.grid] {
        display: none;
    }

    [wire\:offline] {
        display: none;
    }

    [wire\:dirty]:not(textarea):not(input):not(select) {
        display: none;
    }

    input:-webkit-autofill, select:-webkit-autofill, textarea:-webkit-autofill {
        animation-duration: 50000s;
        animation-name: livewireautofill;
    }

    @keyframes livewireautofill { from {} }
</style>
<link rel="stylesheet" href="http://localhost:8000/vendor/tailwind.css" />
<link rel="stylesheet" href="http://localhost:8000/vendor/laravel-views.css" />
    <?php echo \Livewire\Livewire::styles(); ?>




</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern 2-columns  navbar-floating footer-static  " data-open="click" data-menu="vertical-menu-modern" data-col="2-columns">

<?php if(auth()->guard()->check()): ?>
  <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
  <?php echo $__env->make('layouts.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo \Livewire\Livewire::scripts(); ?>

<!-- Livewire Scripts -->

<script src="/vendor/livewire/livewire.js?id=936e5d0fb0b76b631ba7" data-turbo-eval="false" data-turbolinks-eval="false"></script>
<script data-turbo-eval="false" data-turbolinks-eval="false">
    if (window.livewire) {
        console.warn('Livewire: It looks like Livewire\'s @livewireScripts JavaScript assets have already been loaded. Make sure you aren\'t loading them twice.')
    }

    window.livewire = new Livewire();
    window.livewire.devTools(true);
    window.Livewire = window.livewire;
    window.livewire_app_url = '';
    window.livewire_token = 'NFX5cEDjeilcCAv2uZRZTM4umDy499kMCPAgpn4T';

    /* Make sure Livewire loads first. */
    if (window.Alpine) {
        /* Defer showing the warning so it doesn't get buried under downstream errors. */
        document.addEventListener("DOMContentLoaded", function () {
            setTimeout(function() {
                console.warn("Livewire: It looks like AlpineJS has already been loaded. Make sure Livewire\'s scripts are loaded before Alpine.\n\n Reference docs for more info: http://laravel-livewire.com/docs/alpine-js")
            })
        });
    }

    /* Make Alpine wait until Livewire is finished rendering to do its thing. */
    window.deferLoadingAlpine = function (callback) {
        window.addEventListener('livewire:load', function () {
            callback();
        });
    };

    document.addEventListener("DOMContentLoaded", function () {
        window.livewire.start();
    });
</script>
<script src="http://localhost:8000/vendor/laravel-views.js" type="text/javascript"></script>
<script type="text/javascript">
    window.livewire.on('data-update', () => {
        $('.ModalCenter').modal('hide');
        $('.ModalCenterEdit').modal('hide');

    });
    window.livewire.on('data-deleted', () => {
        $('.DeleteModalCenter').modal('hide');
    });

    window.addEventListener('open-updat', event => {

    $('#exampleModalCenter').modal('show')
    $('#editeModel').modal('show')
    $('#imageUpdate').modal('show')
})

    window.addEventListener('open-delete', event => {

    $('#deleteData').modal('show')
})

</script>
<?php echo $__env->yieldPushContent('jsw'); ?>
</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/layouts/master.blade.php ENDPATH**/ ?>