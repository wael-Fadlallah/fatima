
      <?php echo $__env->yieldContent('content'); ?>

<?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/layouts/content.blade.php ENDPATH**/ ?>