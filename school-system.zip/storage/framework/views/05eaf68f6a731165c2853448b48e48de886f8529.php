<div>

    <p>

        <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
            أضف  حلقة دراسه
        </button>
    </p>



    <!-- image  Field -->
    <div class="row">
        <div class="col-12">
            <?php if(session()->has('message')): ?>
                <div class="alert col-12 alert-success m-2 p-1">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <div class="alert col-12 alert-danger m-1">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
        </div>
        <div class="col-12">

            <table class="table" width="100%">
                <thead>
                <tr>
                    <th>#</th>
                    <th> اسم الحلقة </th>
                    <th> الدوام </th>
                    <th> المعلمه </th>
                    <th>تحكم الحلقة</th>
                    <th>التحكم</th>
                </tr>

                </thead>
                <tbody>
                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>#<?php echo e($classe->id); ?></td>
                        <td> <?php echo e($classe->name); ?> </td>
                        <td> <?php echo e($classe->ShiftName); ?> </td>
                        <td> <?php echo e($classe->teacher->name??''); ?> </td>

                        <td><a href="/students/<?php echo e($classe->id); ?>" class="btn btn-outline-info" >إضافة طالبات </a>
                        <a class="btn btn-outline-info" href="/result/<?php echo e($classe->id); ?>">إضافة نتائج الإختبارات </a>
                       <a class="btn btn-outline-primary" href="/certificate/<?php echo e($classe->id); ?>"> طباعة الشهادات </a> </td>
                        <td><button class="btn btn-outline-dark" wire:click="upadteteacherModel(<?php echo e($classe->id); ?>,'update')" >تعديل </button>

                            <button class="btn btn-outline-danger" wire:click="confirmDelete(<?php echo e($classe->id); ?>,'delete')" ><span class="fa fa-trash"></span></button>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr><td colspan="3"> <?php echo e($classes->links()); ?> </td></tr>
                </tbody>
            </table>

        </div>
        </div>
        </div>






    <!-- Modal -->
    <div class="modal fade ModalCenter" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle"> أضف  حلقة دراسه </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('classes.form')->html();
} elseif ($_instance->childHasBeenRendered('T5eXxqS')) {
    $componentId = $_instance->getRenderedChildComponentId('T5eXxqS');
    $componentTag = $_instance->getRenderedChildComponentTagName('T5eXxqS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('T5eXxqS');
} else {
    $response = \Livewire\Livewire::mount('classes.form');
    $html = $response->html();
    $_instance->logRenderedChild('T5eXxqS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                </div>
            </div>
        </div>
    </div>


        </div>


   

<!-- Modal -->
<div class="modal fade DeleteModalCenter" id="deleteData" tabindex="-1" role="dialog"
     aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">هل تريد حذف  ؟ </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-center">

                <div class="btn btn-danger" wire:click="confirmDelete">
                    تأكيد
                </div>


            </div>

        </div>
    </div>
</div>

</div><?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/livewire/classes/index.blade.php ENDPATH**/ ?>