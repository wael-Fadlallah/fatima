<div>
    <div class="row m-3">
        <div class="col-12">
            <?php if(session()->has('message')): ?>
                <div class="alert col-12 alert-success">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-12 mb-2"><h2 class="text-center">أدخل إسم الحلقة الدراسه </h2></div>
        <div class="col-12">
            <lable>إسم الحلقة</lable>
            <div class="input-group col-12"><input type="text" name="name" wire:model="name" class="form-control"
                                                   placeholder="مثلا أول أمهات ">

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="col-12"><span class="error text-danger"><?php echo e($message); ?></span></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
            <?php if(auth()->user()->hasRole('admin')): ?>
                <div class="col-12">
                    <div class="input-group ">
                        <lable class="col-12"> الدوام</lable>
                        <select type="text" name="shift" wire:model="shift" class="form-control col-12"
                                placeholder="مثلا أول أمهات ">
                            <option value="0">إختر الدوام</option>
                            <option value="1">صباحي</option>
                            <option value="2">مسائي</option>
                        </select>

                        <?php $__errorArgs = ['shift'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="col-12"><span class="error text-danger"><?php echo e($message); ?></span></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                </div>
                <?php else: ?>

                <?php endif; ?>
            <div class="col-12">
                <div class="input-group ">
                    <lable class="col-12"> المعلمه</lable>
                    <select type="text" name="teacher_id" wire:model="teacher_id" class="form-control col-12"
                         >
                        <option value="0">إختر المعلمة</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <?php $__errorArgs = ['teacher_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="col-12"><span class="error text-danger"><?php echo e($message); ?></span></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>


            <div class="col-12 m-1 text-center">
                <button wire:click="save" class=" btn btn-outline-info">
                    حفظ
                </button>

            </div>
        </div>
    </div>
<?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/livewire/classes/form.blade.php ENDPATH**/ ?>