<?php $__env->startSection('title','home'); ?>


<?php $__env->startPush('style'); ?>
    <!-- BEGIN: Page CSS-->

    <!-- END: Page CSS-->
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>
    <!-- BEGIN: Page JS-->

    <!-- END: Page JS-->

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">

                <!-- Dashboard Analytics Start -->
                <section id="dashboard-analytics">


                    <div class="card">
                        <div class="card-body">

                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teachers.teacher')->html();
} elseif ($_instance->childHasBeenRendered('jcQZtHI')) {
    $componentId = $_instance->getRenderedChildComponentId('jcQZtHI');
    $componentTag = $_instance->getRenderedChildComponentTagName('jcQZtHI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jcQZtHI');
} else {
    $response = \Livewire\Livewire::mount('teachers.teacher');
    $html = $response->html();
    $_instance->logRenderedChild('jcQZtHI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>






                        </div>
                    </div>

                </section>
                <!-- Dashboard Analytics end -->
            </div>
        </div>
    </div>
    <!-- END: Content-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/admin/teachers/teachers.blade.php ENDPATH**/ ?>