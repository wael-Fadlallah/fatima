<div>
    <div class="row">














        






























    </div>

    <?php if($students): ?>
      <div class="row">
          <div class="col-12">
              <?php if(session()->has('message')): ?>
                  <div class="alert col-12 alert-success">
                      <?php echo e(session('message')); ?>

                  </div>
              <?php endif; ?>
                  <?php if(session()->has('error')): ?>
                  <div class="alert col-12 alert-danger">
                      <?php echo e(session('error')); ?>

                  </div>
              <?php endif; ?>
          </div>
          <div class="col-6">
      <table class="table">
         <tr>
             <th>
                 إسم الطالبه
             </th>
         </tr>

              <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                     <td>
                         <?php echo e($student->name); ?>

                     </td>
                     <td>

                    <button wire:click="showCertificate(<?php echo e($student->id); ?>)"  class="btn btn-primary "> عرض الشهاده </button>




                     </td>
                 </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </table>
              <?php $__errorArgs = ['student'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span
                  class="error text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
      </div>
        <div class="col-12 text-center">

        </div>
        <?php endif; ?>



</div>
<?php /**PATH C:\Users\android dev\Documents\GitHub\laravel\school-system\resources\views/livewire/classes/students/certificate.blade.php ENDPATH**/ ?>